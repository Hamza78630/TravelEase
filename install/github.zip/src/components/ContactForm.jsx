import React, { useState } from 'react';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [submittedData, setSubmittedData] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmittedData(formData);
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  return (
    <>
      <div className="form-container">
        <form onSubmit={handleSubmit}>
          <fieldset>
            <legend>Contact Us</legend>

            <table>
              <tbody>
                <tr>
                  <td><label>Name:</label></td>
                  <td>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td><label>Email:</label></td>
                  <td>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td><label>Subject:</label></td>
                  <td>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td colSpan="2">
                    Message:
                    <br /><br />
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                    />
                  </td>
                </tr>

                <tr>
                  <td colSpan="2" align="center">
                    <input type="submit" value="Send Message" />
                  </td>
                </tr>
              </tbody>
            </table>
          </fieldset>
        </form>
      </div>

      {submittedData && (
        <div className="form-container">
          <fieldset>
            <legend>Submitted Details</legend>

            <table>
              <tbody>
                <tr>
                  <td>Name:</td>
                  <td>{submittedData.name}</td>
                </tr>
                <tr>
                  <td>Email:</td>
                  <td>{submittedData.email}</td>
                </tr>
                <tr>
                  <td>Subject:</td>
                  <td>{submittedData.subject}</td>
                </tr>
                <tr>
                  <td>Message:</td>
                  <td>{submittedData.message}</td>
                </tr>
              </tbody>
            </table>
          </fieldset>
        </div>
      )}
    </>
  );
};

export default ContactForm;
