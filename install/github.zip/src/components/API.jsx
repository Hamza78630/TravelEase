import CountriesList from "./CountriesList"

const API = () => {
    return(
        <>
        <CountriesList />
        </>        
    )
}

export default API;