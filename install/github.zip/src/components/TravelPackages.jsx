const TravelPackages = () => {
  return (
    <>
      <h1>Travel Packages</h1>
      <p className="intro-text">
        "Discover our carefully curated travel packages designed for comfort,
        adventure, and unforgettable experiences."
      </p>

      <div className="packages-container">
        <div className="package-card">
          <img src="/images/paris.jpg" alt="Paris" />
          <h3>Paris Getaway</h3>
          <p>5 Days / 4 Nights</p>
          <ul>
            <li>Hotel Accommodation</li>
            <li>City Tours</li>
            <li>Airport Transfers</li>
          </ul>
          <span className="price">$1,200</span>
          <button>Book Now</button>
        </div>

        <div className="package-card">
          <img src="/images/dubai.jpg" alt="Dubai" />
          <h3>Dubai Luxury Tour</h3>
          <p>4 Days / 3 Nights</p>
          <ul>
            <li>Luxury Hotel</li>
            <li>Desert Safari</li>
            <li>Burj Khalifa Visit</li>
          </ul>
          <span className="price">$950</span>
          <button>Book Now</button>
        </div>

        <div className="package-card">
          <img src="/images/istanbul.jpg" alt="Istanbul" />
          <h3>Istanbul Cultural Tour</h3>
          <p>6 Days / 5 Nights</p>
          <ul>
            <li>Historical Tours</li>
            <li>Bosphorus Cruise</li>
            <li>Local Guide</li>
          </ul>
          <span className="price">$1,050</span>
          <button>Book Now</button>
        </div>
      </div>
    </>
  );
};

export default TravelPackages;
