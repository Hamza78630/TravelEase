const About = () => {
  return (
    <>
      <div className="section">
        <h1>About TravelEase</h1>
      </div>

      <div id="top-images">
        <img src="/images/team.jpg" alt="Image 1" />
        <img src="/images/team2.jpg" alt="Image 2" />
        <img src="/images/team3.jpg" alt="Image 3" />
        <img src="/images/team4.jpg" alt="Image 4" />
      </div>

      <div className="section">
        <h2>History</h2>
        <p>
          <b><i>TravelEase</i></b> was founded in 2022 with the goal of making travel planning simple and stress-free for everyone. 
          What started as a small project connecting travelers with local transport services quickly grew into a full-fledged platform 
          offering airline bookings, hotel reservations, guided tours, and more. Over the years, TravelEase has helped thousands of travelers 
          explore new destinations, discover hidden gems, and enjoy safe, memorable journeys.
        </p>

        <h2>Our Mission</h2>
        <p>
          At <b><i>TravelEase</i></b>, our mission is to make traveling simple, affordable, and enjoyable for everyone. 
          We aim to connect travelers with trusted transport services, reliable accommodations, and expert local guides, 
          so every journey is smooth, safe, and memorable.
        </p>
      </div>

      <div className="section">
        <h2>Meet The Team</h2>
        <table className="about-table">
          <tr>
            <th>Photo</th>
            <th>Name</th>
            <th>Job</th>
            <th>Short Description</th>
          </tr>
          <tr>
            <td><img src="/images/CEO.jpg" alt="CEO" /></td>
            <td>Ali Khan</td>
            <td>CEO & Founder</td>
            <td>Founder of TravelEase, passionate about creating smooth travel experiences for everyone.</td>
          </tr>
          <tr>
            <td><img src="/images/Marketing.jpg" alt="Marketing" /></td>
            <td>Sara Ahmed</td>
            <td>Marketing Head</td>
            <td>Leads marketing campaigns and partnerships to expand TravelEase’s reach.</td>
          </tr>
          <tr>
            <td><img src="/images/CustomerManage.jpg" alt="Customer Manager" /></td>
            <td>Ahmed Raza</td>
            <td>Customer Support Manager</td>
            <td>Ensures travelers get help 24/7 and have hassle-free journeys.</td>
          </tr>
          <tr>
            <td><img src="/images/OP Manager.jpg" alt="Operations Manager" /></td>
            <td>Nadia Hussain</td>
            <td>Operations Manager</td>
            <td>Oversees day-to-day operations and coordinates with transport services.</td>
          </tr>
          <tr>
            <td><img src="/images/Web Dev.jpg" alt="Web Developer" /></td>
            <td>Bilal Shah</td>
            <td>Web Developer</td>
            <td>Designs and maintains the TravelEase website for smooth user experience.</td>
          </tr>
        </table>
      </div>
    </>
  );
}

export default About;
