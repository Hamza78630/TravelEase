import ContactForm from './ContactForm';

const Contact = () => {
  return (
    <>
      <h1>Contact Us</h1>

      <div className="intro-text">
        "We value your feedback and are always here to help! Whether you have questions, suggestions, or need assistance with your bookings, our team at <b>TravelEase</b> is ready to listen. 
        Reach out to us — your satisfaction means the world to us."
      </div>

      <ContactForm />

      <div className="additional-info">
        <p><b>Office Address: </b> DHA Phase 8, Lahore</p>
        <p><b>Office Hours: </b> 8 am - 11 pm</p>
      </div>
    </>
  );
}

export default Contact;
