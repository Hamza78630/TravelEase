import RegistrationForm from './RegistrationForm';

function Registration() {
  return (
    <>
      <h1>Registration</h1>

      <div className="intro-text">
      "Join <b>TravelEase</b> today and make your travel planning easier than ever! By creating your free account, you’ll gain
        access to exclusive discounts, personalized trip recommendations, and priority customer support. Whether you’re planning a
        family vacation or an adventure getaway, registering with <b>TravelEase</b> ensures a smoother, faster, and more enjoyable
        booking experience."
      </div>

      <RegistrationForm />

      <div className="additional-info">
        <p><b>Office Address:</b> DHA Phase 8, Lahore</p>
        <p><b>Office Hours:</b> 8 am - 11 pm</p>
      </div>

    </>
  );
}

export default Registration;
